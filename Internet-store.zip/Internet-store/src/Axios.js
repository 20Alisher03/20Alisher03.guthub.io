import axios from 'axios'

const api = axios.create({
  baseURL: 'https://43812e1690ded861.mokky.dev'
})

export default api
