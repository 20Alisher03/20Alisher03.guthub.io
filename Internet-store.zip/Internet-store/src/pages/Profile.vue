<template>
  <h2 class="text-3xl font-bold mb-8">Мой Профиль</h2>
  <h3 class="text-xl">Персональные данные</h3>

  <div class="grid grid-cols-3 gap-10 mt-10">
    <input placeholder="Имя" type="text" />
    <input placeholder="Фамилия" type="text" />
    <input placeholder="Отчество" type="text" />
    <input placeholder="Дата рождения" type="number" />
    <input placeholder="Телефон" type="number" />
    <input placeholder="Email" type="email" />
  </div>

  <div class="text-xl font-bold mt-20">Расскажите о себе</div>
  <p class="mt-5">На основе ваших данных мы персонализируем ваш поиск</p>
</template>
